--[[
    UI Cast Bar  (WoW 3.3.5a)  -  Autor: vash
    - Barra de casteo del jugador (icono, spark, latencia, texto de nombre y tiempo)
    - Fondo rojo completo cuando el casteo falla / es interrumpido
    - Temporizadores de swing: mano principal, mano izquierda y a distancia
    - Todo configurable con /ucb
]]
local ADDON_NAME, ns = ...
ns = ns or {}
_G.UICastBar = ns

local UCB = CreateFrame("Frame", "UICastBarEventFrame", UIParent)
ns.UCB = UCB

local GetTime = GetTime
local UnitCastingInfo, UnitChannelInfo = UnitCastingInfo, UnitChannelInfo
local floor, max, min, abs = math.floor, math.max, math.min, math.abs
local format, lower = string.format, string.lower
local pairs, ipairs, type, unpack, tsort, tinsert = pairs, ipairs, type, unpack, table.sort, table.insert

local WHITE = "Interface\\Buttons\\WHITE8x8"
local SPARK = "Interface\\CastingBar\\UI-CastingBar-Spark"
local FALLBACK_FONT = ns.LOCAL_FONT
local QUESTION = "Interface\\Icons\\INV_Misc_QuestionMark"

local T = ns.T
local DB            -- se asigna en ADDON_LOADED
local Bars = {}     -- Bars.cast / mh / oh / ranged
local BarList = {}
ns.Bars = Bars

---------------------------------------------------------------------------
-- Utilidades
---------------------------------------------------------------------------
local function SetSize(f, w, h) f:SetWidth(w); f:SetHeight(h) end

local function Print(msg)
    DEFAULT_CHAT_FRAME:AddMessage("|cff33ff99UICastBar|r: " .. tostring(msg))
end
ns.Print = Print

local function CopyDefaults(src, dst)
    for k, v in pairs(src) do
        if type(v) == "table" then
            if type(dst[k]) ~= "table" then dst[k] = {} end
            CopyDefaults(v, dst[k])
        elseif dst[k] == nil then
            dst[k] = v
        end
    end
end

---------------------------------------------------------------------------
-- Valores por defecto (replican el WeakAura original)
---------------------------------------------------------------------------
local function TextDefaults(o)
    local t = {
        enabled = true, font = "Friz Quadrata TT", size = 12, outline = "OUTLINE",
        color = {1, 1, 1, 1}, align = "RIGHT", x = 0, y = 0, shadow = false,
    }
    for k, v in pairs(o or {}) do t[k] = v end
    return t
end

local function BarDefaults(o)
    local d = {
        enabled = true,
        width = 220, height = 22, scale = 1, x = 0, y = 0, alpha = 1, strata = "HIGH",
        texture = "Blizzard",
        color = {0.9647, 0.6157, 0, 1},
        bgColor = {0, 0, 0, 0.2},
        fill = "FILL",
        border = { enabled = true, style = "Blizzard Tooltip", size = 12, offset = 1, color = {0, 0, 0, 1} },
        spark = { enabled = true, texture = SPARK, color = {1, 1, 1, 1}, width = 30, height = 40, hideWhenEmpty = false },
        nameText = TextDefaults({ enabled = false, align = "LEFT" }),
        timeText = TextDefaults(),
        timeFormat = "REMAIN_TOTAL",
    }
    for k, v in pairs(o or {}) do d[k] = v end
    return d
end

local function SwingDefaults(color, bg, y)
    return BarDefaults({
        width = 278, height = 15, scale = 0.8, x = 0, y = y,
        color = color, bgColor = bg,
        border = { enabled = true, style = "Blizzard Tooltip", size = 12, offset = 1, color = {0, 0, 0, 1} },
        spark = { enabled = true, texture = WHITE, color = {1, 0.9451, 0, 1}, width = 3, height = 15, hideWhenEmpty = true },
        icon = { enabled = true, side = "LEFT" },
    })
end

local function MakeDefaults()
    local d = {
        hideBlizzard = true,
        groupMove = false,
        cast = BarDefaults({
            width = 220, height = 22, scale = 0.88, x = 9.6, y = -334,
            color = {0.9647, 0.6157, 0, 1},
            bgColor = {0, 0, 0, 0.2},
            fill = "FILL", channelFill = "DRAIN",
            border = { enabled = true, style = "Gladdy Tooltip squared", size = 17, offset = 5, color = {0, 0, 0, 1} },
            spark = { enabled = true, texture = SPARK, color = {1, 1, 1, 1}, width = 30, height = 40, hideWhenEmpty = false },
            nameText = TextDefaults({ enabled = true, font = "Emblem", size = 12, outline = "MONOCHROMEOUTLINE", align = "LEFT" }),
            timeText = TextDefaults({ enabled = true, font = "Emblem", size = 13, outline = "OUTLINE", align = "RIGHT" }),
            icon = {
                enabled = true, size = 28, x = -125, y = 0, zoom = true,
                pop = { enabled = true, scale = 1.5, duration = 0.3 },
                border = { enabled = true, style = "Solid", size = 2, offset = 1, color = {0, 0, 0, 1} },
            },
            latency = { enabled = true, color = {1, 0, 0, 0.5} },
            endColor = { enabled = true, threshold = 0.15, color = {0, 1, 0, 1} },
            fail = {
                enabled = true, color = {1, 0, 0, 1}, duration = 1.0,
                failedText = T("Fallido"), interruptedText = T("Interrumpido"), cancelText = T("Cancelado"), showWithoutCast = false,
            },
        }),
        mh     = SwingDefaults({1, 0.0353, 0, 1},          {0, 0, 0, 0.31}, -311),
        oh     = SwingDefaults({1, 0.9569, 0.4627, 1},     {0, 0, 0, 0.38}, -295),
        ranged = SwingDefaults({0.2275, 0, 1, 1},          {0, 0, 0, 0.42}, -311),
    }
    return d
end
ns.MakeDefaults = MakeDefaults

---------------------------------------------------------------------------
-- Medios (texturas / fuentes / bordes) con soporte opcional de LibSharedMedia
---------------------------------------------------------------------------
local LSM
local function GetLSM()
    if not LSM and LibStub then LSM = LibStub("LibSharedMedia-3.0", true) end
    return LSM
end

local BUILTIN = {
    statusbar = {
        ["Blizzard"] = "Interface\\TargetingFrame\\UI-StatusBar",
        ["Flat"] = WHITE,
        ["Raid"] = "Interface\\RaidFrame\\Raid-Bar-Hp-Fill",
        ["Skills"] = "Interface\\PaperDollInfoFrame\\UI-Character-Skills-Bar",
    },
    font = {
        ["Friz Quadrata TT"] = "Fonts\\FRIZQT__.TTF",
        ["Arial Narrow"] = "Fonts\\ARIALN.TTF",
        ["Skurri"] = "Fonts\\skurri.ttf",
        ["Morpheus"] = "Fonts\\MORPHEUS.TTF",
    },
    border = {
        ["Blizzard Tooltip"] = "Interface\\Tooltips\\UI-Tooltip-Border",
        ["Blizzard Dialog"] = "Interface\\DialogFrame\\UI-DialogBox-Border",
        ["Solid"] = WHITE,
    },
}
local DEFAULT_MEDIA = { statusbar = "Blizzard", font = "Friz Quadrata TT", border = "Blizzard Tooltip" }

-- devuelve ruta, encontrado
local function Fetch(kind, name)
    local lsm = GetLSM()
    if name then
        local p = lsm and lsm:Fetch(kind, name, true)
        if p then return p, true end
        p = BUILTIN[kind][name]
        if p then return p, true end
    end
    return BUILTIN[kind][DEFAULT_MEDIA[kind]], false
end
ns.Fetch = Fetch

function ns.ListMedia(kind)
    local out, seen = {}, {}
    for k in pairs(BUILTIN[kind]) do seen[k] = true; out[#out + 1] = k end
    local lsm = GetLSM()
    if lsm then
        local list = lsm:List(kind)
        if list then
            for _, k in ipairs(list) do
                if not seen[k] then seen[k] = true; out[#out + 1] = k end
            end
        end
    end
    tsort(out, function(a, b) return lower(a) < lower(b) end)
    if kind == "border" then tinsert(out, 1, "None") end
    return out
end

local FLAGS = {
    NONE = "", OUTLINE = "OUTLINE", THICKOUTLINE = "THICKOUTLINE",
    MONOCHROME = "MONOCHROME", MONOCHROMEOUTLINE = "OUTLINE,MONOCHROME",
}

local function SetFontSafe(fs, fontName, size, outline)
    local path = Fetch("font", fontName)
    if ns.NONLATIN and (fontName == "Emblem" or fontName == "Friz Quadrata TT") then
        path = ns.LOCAL_FONT   -- fuente del cliente con soporte de cirilico / chino / coreano
    end
    local flags = FLAGS[outline] or ""
    size = size or 12
    if not fs:SetFont(path, size, flags) then
        fs:SetFont(FALLBACK_FONT, size, flags)
    end
end
ns.SetFontSafe = SetFontSafe

---------------------------------------------------------------------------
-- Formato de tiempo
---------------------------------------------------------------------------
local function FormatTime(fmt, remain, total)
    if fmt == "REMAIN_TOTAL" then
        return format("%.1f / %.1f", remain, total)
    elseif fmt == "ELAPSED_TOTAL" then
        return format("%.1f / %.1f", total - remain, total)
    elseif fmt == "REMAIN" then
        return format("%.1f", remain)
    elseif fmt == "ELAPSED" then
        return format("%.1f", total - remain)
    end
    return ""
end

---------------------------------------------------------------------------
-- Driver de OnUpdate (solo corre cuando hay algo activo)
---------------------------------------------------------------------------
local driver = CreateFrame("Frame")
local UpdateBar, TestStep

local function DriverOnUpdate(self)
    local now = GetTime()
    local any = false
    if UCB.test then TestStep(now); any = true end
    for i = 1, #BarList do
        local b = BarList[i]
        local st = b.state
        if st and st ~= "preview" then
            if UpdateBar(b, now) then any = true end
        end
    end
    if not any then
        self:SetScript("OnUpdate", nil)
        self.running = false
    end
end

local function Wake()
    if not driver.running then
        driver.running = true
        driver:SetScript("OnUpdate", DriverOnUpdate)
    end
end

---------------------------------------------------------------------------
-- Creación de barras
---------------------------------------------------------------------------
local function GetBarXY(bar)
    local f = bar.frame
    local cx, cy = f:GetCenter()
    if not cx then return end
    local s = f:GetEffectiveScale() / UIParent:GetEffectiveScale()
    return cx * s - UIParent:GetWidth() / 2, cy * s - UIParent:GetHeight() / 2
end

local groupDrag
local groupFrame = CreateFrame("Frame")

local function GroupUpdate()
    local g = groupDrag
    if not g then return end
    local x, y = GetBarXY(g.bar)
    if not x then return end
    for _, b in ipairs(BarList) do
        if b ~= g.bar then
            local c, st = DB[b.key], g.starts[b.key]
            c.x = st.x + (x - g.sx)
            c.y = st.y + (y - g.sy)
            local s = c.scale
            b.frame:ClearAllPoints()
            b.frame:SetPoint("CENTER", UIParent, "CENTER", c.x / s, c.y / s)
        end
    end
end

local function BeginGroupDrag(bar)
    local sx, sy = GetBarXY(bar)
    if not sx then return end
    groupDrag = { bar = bar, sx = sx, sy = sy, starts = {} }
    for _, b in ipairs(BarList) do
        groupDrag.starts[b.key] = { x = DB[b.key].x, y = DB[b.key].y }
    end
    groupFrame:SetScript("OnUpdate", GroupUpdate)
end

local function SavePosition(bar)
    local x, y = GetBarXY(bar)
    if not x then return end
    local cfg = DB[bar.key]
    cfg.x = floor(x * 10 + 0.5) / 10
    cfg.y = floor(y * 10 + 0.5) / 10
    if groupDrag then
        GroupUpdate()
        groupFrame:SetScript("OnUpdate", nil)
        groupDrag = nil
        for _, b in ipairs(BarList) do
            local c = DB[b.key]
            c.x = floor(c.x * 10 + 0.5) / 10
            c.y = floor(c.y * 10 + 0.5) / 10
        end
        ns.ApplyAll()
    else
        ns.ApplyKey(bar.key)
    end
    if ns.RefreshOptions then ns.RefreshOptions() end
end

local function CreateBar(key, label, insideIcon, isCast)
    local bar = { key = key, label = label, insideIcon = insideIcon, isCast = isCast }
    local f = CreateFrame("Frame", "UICastBar_" .. key, UIParent)
    f:Hide()
    f:SetMovable(true)
    f:SetClampedToScreen(true)
    bar.frame = f

    bar.bg = f:CreateTexture(nil, "BACKGROUND")

    local sb = CreateFrame("StatusBar", nil, f)
    sb:SetMinMaxValues(0, 1)
    sb:SetValue(0)
    sb:SetStatusBarTexture(BUILTIN.statusbar.Blizzard)
    bar.sb = sb
    bar.bg:SetAllPoints(sb)

    bar.lat = sb:CreateTexture(nil, "OVERLAY")
    bar.lat:Hide()
    bar.spark = sb:CreateTexture(nil, "OVERLAY")
    bar.spark:SetBlendMode("ADD")

    local bd = CreateFrame("Frame", nil, f)
    bar.border = bd
    bd:EnableMouse(false)

    local tf = CreateFrame("Frame", nil, f)
    tf:SetAllPoints(f)
    tf:EnableMouse(false)
    bar.tf = tf

    local lvl = f:GetFrameLevel()
    sb:SetFrameLevel(lvl + 1)
    bd:SetFrameLevel(lvl + 2)
    tf:SetFrameLevel(lvl + 3)

    bar.nameText = tf:CreateFontString(nil, "OVERLAY")
    bar.nameText:SetFont(FALLBACK_FONT, 12, "")
    bar.timeText = tf:CreateFontString(nil, "OVERLAY")
    bar.timeText:SetFont(FALLBACK_FONT, 12, "")

    if insideIcon then
        bar.icon = f:CreateTexture(nil, "ARTWORK")
    end

    local function OnDragStart()
        if UCB.unlocked then
            if DB.groupMove then BeginGroupDrag(bar) end
            f:StartMoving()
        end
    end
    local function OnDragStop()
        f:StopMovingOrSizing()
        SavePosition(bar)
    end
    f:RegisterForDrag("LeftButton")
    f:SetScript("OnDragStart", OnDragStart)
    f:SetScript("OnDragStop", OnDragStop)

    if isCast then
        local ic = CreateFrame("Frame", nil, f)
        ic:SetFrameLevel(lvl + 1)
        bar.iconFrame = ic
        bar.iconTex = ic:CreateTexture(nil, "ARTWORK")
        bar.iconTex:SetAllPoints(ic)
        local ib = CreateFrame("Frame", nil, ic)
        ib:SetFrameLevel(lvl + 2)
        ib:EnableMouse(false)
        bar.iconBorder = ib
        ic:RegisterForDrag("LeftButton")
        ic:SetScript("OnDragStart", OnDragStart)
        ic:SetScript("OnDragStop", OnDragStop)
    end

    Bars[key] = bar
    BarList[#BarList + 1] = bar
    return bar
end

---------------------------------------------------------------------------
-- Aplicar configuración a una barra
---------------------------------------------------------------------------
local function ApplyBorder(frame, anchor, b)
    if not b or not b.enabled or b.style == "None" then
        frame:SetBackdrop(nil)
        return
    end
    local path, found = Fetch("border", b.style)
    local size = b.size or 12
    if not found and size > 14 then size = 12 end
    frame:ClearAllPoints()
    frame:SetPoint("TOPLEFT", anchor, "TOPLEFT", -b.offset, b.offset)
    frame:SetPoint("BOTTOMRIGHT", anchor, "BOTTOMRIGHT", b.offset, -b.offset)
    frame:SetBackdrop({ edgeFile = path, edgeSize = size })
    frame:SetBackdropBorderColor(unpack(b.color))
end

local function ApplyText(fs, t, anchor)
    SetFontSafe(fs, t.font, t.size, t.outline)
    fs:SetTextColor(unpack(t.color))
    if t.shadow then
        fs:SetShadowColor(0, 0, 0, 1)
        fs:SetShadowOffset(1, -1)
    else
        fs:SetShadowColor(0, 0, 0, 0)
        fs:SetShadowOffset(0, 0)
    end
    fs:ClearAllPoints()
    local x, y = t.x or 0, t.y or 0
    if t.align == "LEFT" then
        fs:SetPoint("LEFT", anchor, "LEFT", 3 + x, y)
        fs:SetJustifyH("LEFT")
    elseif t.align == "CENTER" then
        fs:SetPoint("CENTER", anchor, "CENTER", x, y)
        fs:SetJustifyH("CENTER")
    else
        fs:SetPoint("RIGHT", anchor, "RIGHT", -3 + x, y)
        fs:SetJustifyH("RIGHT")
    end
    if t.enabled then fs:Show() else fs:Hide() end
end

local function ApplyBar(bar)
    local cfg = DB[bar.key]
    local f, sb = bar.frame, bar.sb
    local w, h, s = cfg.width, cfg.height, cfg.scale
    if s < 0.1 then s = 0.1 end

    f:SetFrameStrata(cfg.strata or "HIGH")
    f:SetAlpha(cfg.alpha or 1)
    f:SetScale(s)
    SetSize(f, w, h)
    f:ClearAllPoints()
    f:SetPoint("CENTER", UIParent, "CENTER", cfg.x / s, cfg.y / s)

    local left, right = 0, 0
    if bar.insideIcon then
        if cfg.icon.enabled then
            local ic = bar.icon
            SetSize(ic, h, h)
            ic:ClearAllPoints()
            if cfg.icon.side == "RIGHT" then
                ic:SetPoint("RIGHT", f, "RIGHT", 0, 0); right = h
            else
                ic:SetPoint("LEFT", f, "LEFT", 0, 0); left = h
            end
            ic:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            ic:Show()
        else
            bar.icon:Hide()
        end
    end
    sb:ClearAllPoints()
    sb:SetPoint("TOPLEFT", f, "TOPLEFT", left, 0)
    sb:SetPoint("BOTTOMRIGHT", f, "BOTTOMRIGHT", -right, 0)
    bar.sbWidth = max(1, w - left - right)

    local tex = Fetch("statusbar", cfg.texture)
    sb:SetStatusBarTexture(tex)
    local sbt = sb:GetStatusBarTexture()
    if sbt then sbt:SetHorizTile(false) end
    bar.bg:SetTexture(tex)
    bar.bg:SetVertexColor(unpack(cfg.bgColor))

    if bar.state ~= "fail" then
        sb:SetStatusBarColor(unpack(cfg.color))
    end

    -- spark
    local sp, spc = bar.spark, cfg.spark
    sp:SetTexture(spc.texture or SPARK)
    sp:SetVertexColor(unpack(spc.color))
    SetSize(sp, spc.width, spc.height)

    -- latencia
    if bar.isCast then
        bar.lat:SetTexture(tex)
        bar.lat:SetVertexColor(unpack(cfg.latency.color))
        bar.lat:ClearAllPoints()
        bar.lat:SetPoint("TOPRIGHT", sb, "TOPRIGHT", 0, 0)
        bar.lat:SetPoint("BOTTOMRIGHT", sb, "BOTTOMRIGHT", 0, 0)
    end

    ApplyBorder(bar.border, sb, cfg.border)
    ApplyText(bar.nameText, cfg.nameText, sb)
    ApplyText(bar.timeText, cfg.timeText, sb)

    -- el nombre se acorta con "..." para no tapar el tiempo
    do
        local nt, tt = cfg.nameText, cfg.timeText
        local chars = 11
        if tt.enabled and (cfg.timeFormat == "REMAIN" or cfg.timeFormat == "ELAPSED") then chars = 4 end
        local reserve = (tt.size or 12) * 0.62 * chars + 6
        local avail = bar.sbWidth - 6 - reserve - abs(nt.x or 0)
        if avail < 20 then avail = 20 end
        bar.nameText:SetWidth(avail)
        bar.nameText:SetHeight((nt.size or 12) + 2)
        if bar.nameText.SetWordWrap then bar.nameText:SetWordWrap(false) end
    end

    -- icono externo (barra de casteo)
    if bar.isCast then
        local ic, ci = bar.iconFrame, cfg.icon
        if ci.enabled then
            SetSize(ic, ci.size, ci.size)
            ic:SetScale(1)
            bar.iconScaled = false
            ic:ClearAllPoints()
            ic:SetPoint("CENTER", f, "CENTER", ci.x, ci.y)
            if ci.zoom then bar.iconTex:SetTexCoord(0.07, 0.93, 0.07, 0.93)
            else bar.iconTex:SetTexCoord(0, 1, 0, 1) end
            ApplyBorder(bar.iconBorder, ic, ci.border)
            ic:Show()
        else
            ic:Hide()
        end
    end

    -- ratón / arrastre
    f:EnableMouse(UCB.unlocked and true or false)
    if bar.iconFrame then bar.iconFrame:EnableMouse(UCB.unlocked and true or false) end

    if not cfg.enabled then
        bar.state = nil
        f:Hide()
    end
end

---------------------------------------------------------------------------
-- Estados visuales
---------------------------------------------------------------------------
local function PlaceSpark(bar, v, cfg)
    local sp = bar.spark
    if not cfg.spark.enabled then sp:Hide(); return end
    if cfg.spark.hideWhenEmpty and (v <= 0.001 or v >= 0.999) then sp:Hide(); return end
    sp:ClearAllPoints()
    sp:SetPoint("CENTER", bar.sb, "LEFT", bar.sbWidth * v, 0)
    sp:Show()
end

local function SetIconScale(bar, sc)
    local ic, f, ci = bar.iconFrame, bar.frame, DB.cast.icon
    if not ic then return end
    ic:SetScale(sc)
    ic:ClearAllPoints()
    ic:SetPoint("CENTER", f, "CENTER", ci.x / sc, ci.y / sc)
    bar.iconScaled = (sc ~= 1)
end

local function ResetIcon(bar)
    bar.popStart = nil
    if bar.iconScaled then SetIconScale(bar, 1) end
end

local function PopIcon(bar, now)
    local p = DB.cast.icon.pop
    local t = (now - bar.popStart) / max(p.duration, 0.05)
    if t >= 1 then
        ResetIcon(bar)
    else
        SetIconScale(bar, 1 + (p.scale - 1) * math.sin(math.pi * t))
    end
end

local function ShowBar(bar)
    bar.lastKey = nil
    bar.endColored = false
    bar.frame:Show()
    Wake()
end

local ShowPreview

local function HideBar(bar)
    bar.state = nil
    if bar.isCast then ResetIcon(bar) end
    bar.lat:Hide()
    if UCB.unlocked and DB[bar.key].enabled then
        ShowPreview(bar)
    else
        bar.frame:Hide()
    end
end

ShowPreview = function(bar)
    local cfg = DB[bar.key]
    if not cfg.enabled then return end
    bar.state = "preview"
    bar.lat:Hide()
    bar.sb:SetMinMaxValues(0, 1)
    bar.sb:SetValue(0.6)
    bar.sb:SetStatusBarColor(unpack(cfg.color))
    PlaceSpark(bar, 0.6, cfg)
    bar.nameText:SetText(bar.label)
    bar.timeText:SetText(FormatTime(cfg.timeFormat, 1.2, 3.0))
    if bar.insideIcon and bar.icon then bar.icon:SetTexture(QUESTION) end
    if bar.iconTex then bar.iconTex:SetTexture("Interface\\Icons\\Spell_Fire_FlameBolt") end
    bar.frame:Show()
end

UpdateBar = function(bar, now)
    local st = bar.state
    local cfg = DB[bar.key]
    if st == "fail" then
        if now >= bar.failEnd then HideBar(bar); return false end
        return true
    end
    local dur = bar.dur
    local elapsed = now - bar.start
    if elapsed >= dur then
        if st == "swing" then HideBar(bar); return false end
        if elapsed >= dur + 0.25 and not UnitCastingInfo("player") and not UnitChannelInfo("player") then
            HideBar(bar); return false
        end
        elapsed = dur
    end
    if elapsed < 0 then elapsed = 0 end

    local v = elapsed / dur
    local drain
    if st == "channel" then drain = (cfg.channelFill ~= "FILL") else drain = (cfg.fill == "DRAIN") end
    local sv = drain and (1 - v) or v
    bar.sb:SetValue(sv)
    PlaceSpark(bar, sv, cfg)

    local remain = dur - elapsed
    local key = floor(remain * 10)
    if key ~= bar.lastKey then
        bar.lastKey = key
        if cfg.timeText.enabled then
            bar.timeText:SetText(FormatTime(cfg.timeFormat, remain, dur))
        end
    end

    if bar.isCast and not bar.endColored and cfg.endColor.enabled and remain <= cfg.endColor.threshold then
        bar.endColored = true
        bar.sb:SetStatusBarColor(unpack(cfg.endColor.color))
    end
    if bar.popStart then PopIcon(bar, now) end
    return true
end

---------------------------------------------------------------------------
-- Barra de casteo
---------------------------------------------------------------------------
local sentTime, sentSpell = 0, nil

local function BeginCast(isChannel, name, icon, startTime, dur, latency)
    local bar = Bars.cast
    local cfg = DB.cast
    if not cfg.enabled then return end
    bar.state = isChannel and "channel" or "cast"
    bar.spellName = name
    bar.succeeded = false
    ResetIcon(bar)
    if cfg.icon.enabled and cfg.icon.pop and cfg.icon.pop.enabled then bar.popStart = GetTime() end
    bar.start = startTime
    bar.dur = max(dur, 0.01)
    bar.sb:SetMinMaxValues(0, 1)
    bar.sb:SetStatusBarColor(unpack(cfg.color))
    bar.nameText:SetText(name or "")
    bar.timeText:SetText("")
    if bar.iconTex then bar.iconTex:SetTexture(icon or QUESTION) end
    if cfg.latency.enabled and not isChannel and latency and latency > 0 then
        local frac = min(1, latency / bar.dur)
        bar.lat:SetWidth(max(1, bar.sbWidth * frac))
        bar.lat:Show()
    else
        bar.lat:Hide()
    end
    ShowBar(bar)
end

local function StartFromAPI(isChannel)
    local name, icon, st, et
    if isChannel then
        local n, _, _, ic, s, e = UnitChannelInfo("player")
        name, icon, st, et = n, ic, s, e
    else
        local n, _, _, ic, s, e = UnitCastingInfo("player")
        name, icon, st, et = n, ic, s, e
    end
    if not name or not st or not et then return end
    local latency = 0
    if not isChannel and sentSpell == name then
        latency = GetTime() - sentTime
        if latency < 0 or latency > 2 then latency = 0 end
    end
    BeginCast(isChannel, name, icon, st / 1000, (et - st) / 1000, latency)
end

local function ShowFail(text, force)
    local bar = Bars.cast
    local cfg = DB.cast
    if not cfg.enabled or (not cfg.fail.enabled and not force) then
        HideBar(bar)
        return
    end
    bar.state = "fail"
    ResetIcon(bar)
    bar.failEnd = GetTime() + cfg.fail.duration
    bar.lat:Hide()
    bar.sb:SetMinMaxValues(0, 1)
    bar.sb:SetValue(1)
    bar.sb:SetStatusBarColor(unpack(cfg.fail.color))
    bar.spark:Hide()
    bar.nameText:SetText(text or "")
    bar.timeText:SetText("")
    ShowBar(bar)
end

---------------------------------------------------------------------------
-- Swing timers
---------------------------------------------------------------------------
local SLOT = { mh = 16, oh = 17, ranged = 18 }
local SWING_LABEL = { mh = "Mano principal", oh = "Mano izquierda", ranged = "A distancia" }

local function SwingIcon(key)
    return GetInventoryItemTexture("player", SLOT[key]) or QUESTION
end

local function StartSwing(key, speed)
    local bar, cfg = Bars[key], DB[key]
    if not bar or not cfg.enabled or not speed or speed <= 0 then return end
    bar.state = "swing"
    bar.start = GetTime()
    bar.dur = speed
    bar.sb:SetMinMaxValues(0, 1)
    bar.sb:SetStatusBarColor(unpack(cfg.color))
    bar.nameText:SetText("")
    if bar.icon then bar.icon:SetTexture(SwingIcon(key)) end
    ShowBar(bar)
end

local function OnMeleeSwing(amount)
    local mhSpeed, ohSpeed = UnitAttackSpeed("player")
    local dual = ohSpeed and ohSpeed > 0 and OffhandHasWeapon and OffhandHasWeapon()
    if dual then
        local mh, oh = Bars.mh, Bars.oh
        local now = GetTime()
        local remM = (mh.state == "swing") and (mh.start + mh.dur - now) or 0
        local remO = (oh.state == "swing") and (oh.start + oh.dur - now) or 0
        local useMH = (remM <= remO)
        if amount and abs(remM - remO) < 0.25 then
            -- tiempos ambiguos: desempata por el dano del golpe
            local minM, maxM, minO, maxO = UnitDamage("player")
            if minM and minO and maxM and maxO then
                local mM, mO = (minM + maxM) / 2, (minO + maxO) / 2
                if abs(mM - mO) > 0.15 * max(mM, mO) then
                    useMH = abs(amount - mM) <= abs(amount - mO)
                end
            end
        end
        if useMH then StartSwing("mh", mhSpeed) else StartSwing("oh", ohSpeed) end
    else
        StartSwing("mh", mhSpeed)
    end
end

local nextMelee, rangedSpell = {}, {}

local function BuildSpellSets()
    local melee = { 78, 845, 6807, 2973, 1464, 56815 }    -- Heroic Strike, Cleave, Maul, Raptor Strike, Slam, Rune Strike
    for _, id in ipairs(melee) do
        local n = GetSpellInfo(id)
        if n then nextMelee[n] = true end
    end
    local ranged = { 75, 5019, 2764, 2480, 7918, 7919 }   -- Auto Shot, Shoot, Throw, arcos/armas/ballestas
    for _, id in ipairs(ranged) do
        local n = GetSpellInfo(id)
        if n then rangedSpell[n] = true end
    end
end

local function RescaleSwing(key, newSpeed)
    local bar = Bars[key]
    if bar.state ~= "swing" or not newSpeed or newSpeed <= 0 then return end
    local now = GetTime()
    local remain = bar.start + bar.dur - now
    if remain < 0 then remain = 0 end
    local ratio = remain / bar.dur
    bar.dur = newSpeed
    bar.start = now + ratio * newSpeed - newSpeed
end

---------------------------------------------------------------------------
-- Modo de prueba / desbloqueo
---------------------------------------------------------------------------
local testDur = { mh = 2.4, oh = 2.0, ranged = 1.6 }

TestStep = function(now)
    local t = (now - UCB.testT0) % 8
    local phase = (t < 3 and 1) or (t < 4.5 and 2) or (t < 7.5 and 3) or 4
    if phase ~= UCB.testPhase then
        UCB.testPhase = phase
        if DB.cast.enabled then
            if phase == 1 then
                BeginCast(false, T("Bola de fuego (prueba)"), "Interface\\Icons\\Spell_Fire_FlameBolt", GetTime(), 3, 0.15)
            elseif phase == 2 then
                ShowFail(DB.cast.fail.failedText, true)
            elseif phase == 3 then
                BeginCast(true, T("Canalizar (prueba)"), "Interface\\Icons\\Spell_Arcane_Blast", GetTime(), 3, 0)
            else
                HideBar(Bars.cast)
            end
        end
    end
    for key, d in pairs(testDur) do
        local b = Bars[key]
        if DB[key].enabled and (not b.state or b.state == "preview") then
            StartSwing(key, d)
        end
    end
end

function ns.SetTest(on)
    UCB.test = on and true or false
    if UCB.test then
        UCB.testT0 = GetTime()
        UCB.testPhase = nil
        Wake()
    else
        for _, b in ipairs(BarList) do HideBar(b) end
    end
end

function ns.SetUnlocked(on)
    UCB.unlocked = on and true or false
    for _, b in ipairs(BarList) do
        b.frame:EnableMouse(UCB.unlocked)
        if b.iconFrame then b.iconFrame:EnableMouse(UCB.unlocked) end
        if UCB.unlocked then
            if not b.state then ShowPreview(b) end
        else
            if b.state == "preview" then b.state = nil; b.frame:Hide() end
        end
    end
end

---------------------------------------------------------------------------
-- API para el panel de opciones
---------------------------------------------------------------------------
function ns.ApplyKey(key)
    local bar = Bars[key]
    if bar then
        ApplyBar(bar)
        if bar.state == "preview" then ShowPreview(bar) end
        if UCB.unlocked and DB[key].enabled and not bar.state then ShowPreview(bar) end
        if bar.state == "fail" then bar.sb:SetStatusBarColor(unpack(DB.cast.fail.color)) end
    else
        ns.ApplyAll()
    end
end

function ns.ApplyAll()
    for _, b in ipairs(BarList) do
        ApplyBar(b)
        if b.state == "preview" then ShowPreview(b) end
    end
end

local function HideBlizzardCastBar()
    if not CastingBarFrame then return end
    CastingBarFrame:UnregisterAllEvents()
    CastingBarFrame:Hide()
    if not ns.blizzHooked then
        ns.blizzHooked = true
        CastingBarFrame:HookScript("OnShow", function(self)
            if DB and DB.hideBlizzard then self:Hide() end
        end)
    end
end

local function RestoreBlizzardCastBar()
    if not CastingBarFrame then return end
    local ev = {
        "UNIT_SPELLCAST_START", "UNIT_SPELLCAST_STOP", "UNIT_SPELLCAST_FAILED",
        "UNIT_SPELLCAST_INTERRUPTED", "UNIT_SPELLCAST_DELAYED", "UNIT_SPELLCAST_CHANNEL_START",
        "UNIT_SPELLCAST_CHANNEL_UPDATE", "UNIT_SPELLCAST_CHANNEL_STOP", "PLAYER_ENTERING_WORLD",
    }
    for _, e in ipairs(ev) do CastingBarFrame:RegisterEvent(e) end
end

function ns.ApplyHideBlizzard()
    if DB.hideBlizzard then HideBlizzardCastBar() else RestoreBlizzardCastBar() end
end

function ns.ResetAll()
    for k in pairs(DB) do DB[k] = nil end
    CopyDefaults(MakeDefaults(), DB)
    ns.ApplyAll()
    ns.ApplyHideBlizzard()
    if ns.RefreshOptions then ns.RefreshOptions() end
end

---------------------------------------------------------------------------
-- Eventos
---------------------------------------------------------------------------
local playerGUID

function UCB:ADDON_LOADED(name)
    if name ~= ADDON_NAME then return end
    UICastBarDB = UICastBarDB or {}
    CopyDefaults(MakeDefaults(), UICastBarDB)
    DB = UICastBarDB
    ns.DB = DB
    self:UnregisterEvent("ADDON_LOADED")
end

function UCB:PLAYER_LOGIN()
    playerGUID = UnitGUID("player")
    BuildSpellSets()
    CreateBar("cast", T("Barra de casteo"), false, true)
    CreateBar("mh", T(SWING_LABEL.mh), true, false)
    CreateBar("oh", T(SWING_LABEL.oh), true, false)
    CreateBar("ranged", T(SWING_LABEL.ranged), true, false)
    ns.ApplyAll()
    ns.ApplyHideBlizzard()

    self:RegisterEvent("UNIT_SPELLCAST_SENT")
    self:RegisterEvent("UNIT_SPELLCAST_START")
    self:RegisterEvent("UNIT_SPELLCAST_STOP")
    self:RegisterEvent("UNIT_SPELLCAST_FAILED")
    self:RegisterEvent("UNIT_SPELLCAST_INTERRUPTED")
    self:RegisterEvent("UNIT_SPELLCAST_DELAYED")
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_START")
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_UPDATE")
    self:RegisterEvent("UNIT_SPELLCAST_CHANNEL_STOP")
    self:RegisterEvent("UNIT_SPELLCAST_SUCCEEDED")
    self:RegisterEvent("UNIT_ATTACK_SPEED")
    self:RegisterEvent("UNIT_RANGEDDAMAGE")
    self:RegisterEvent("PLAYER_EQUIPMENT_CHANGED")
    self:RegisterEvent("PLAYER_ENTERING_WORLD")
    self:RegisterEvent("PLAYER_DEAD")
    self:RegisterEvent("COMBAT_LOG_EVENT_UNFILTERED")
end

function UCB:PLAYER_ENTERING_WORLD()
    playerGUID = UnitGUID("player")
    if DB.hideBlizzard then HideBlizzardCastBar() end
end

function UCB:PLAYER_DEAD()
    for _, b in ipairs(BarList) do
        if b.state and b.state ~= "preview" then HideBar(b) end
    end
end

function UCB:UNIT_SPELLCAST_SENT(unit, spell)
    if unit ~= "player" then return end
    sentTime, sentSpell = GetTime(), spell
end

function UCB:UNIT_SPELLCAST_START(unit)
    if unit ~= "player" then return end
    StartFromAPI(false)
end

function UCB:UNIT_SPELLCAST_CHANNEL_START(unit)
    if unit ~= "player" then return end
    StartFromAPI(true)
end

function UCB:UNIT_SPELLCAST_DELAYED(unit)
    if unit ~= "player" then return end
    local bar = Bars.cast
    if bar.state ~= "cast" then return end
    local _, _, _, _, st, et = UnitCastingInfo("player")
    if st and et then
        bar.start = st / 1000
        bar.dur = max((et - st) / 1000, 0.01)
    end
end

function UCB:UNIT_SPELLCAST_CHANNEL_UPDATE(unit)
    if unit ~= "player" then return end
    local bar = Bars.cast
    if bar.state ~= "channel" then return end
    local _, _, _, _, st, et = UnitChannelInfo("player")
    if st and et then
        bar.start = st / 1000
        bar.dur = max((et - st) / 1000, 0.01)
    end
end

function UCB:UNIT_SPELLCAST_STOP(unit)
    if unit ~= "player" then return end
    local bar = Bars.cast
    if bar.state == "cast" and not UnitCastingInfo("player") then
        if not bar.succeeded and (bar.start + bar.dur - GetTime()) > 0.3 then
            ShowFail(DB.cast.fail.cancelText)   -- lo cancelaste tu (movimiento, fake cast, ESC...)
        else
            HideBar(bar)
        end
    end
end

function UCB:UNIT_SPELLCAST_CHANNEL_STOP(unit)
    if unit ~= "player" then return end
    local bar = Bars.cast
    if bar.state == "channel" and not UnitChannelInfo("player") then
        if (bar.start + bar.dur - GetTime()) > 0.3 then
            ShowFail(DB.cast.fail.cancelText)
        else
            HideBar(bar)
        end
    end
end

local function OnCastFailure(unit, textKey)
    if unit ~= "player" then return end
    if UnitCastingInfo("player") or UnitChannelInfo("player") then return end  -- otro intento, no el casteo actual
    local bar = Bars.cast
    local st = bar.state
    if st == "cast" or st == "channel" then
        ShowFail(DB.cast.fail[textKey])
    elseif DB.cast.fail.showWithoutCast and st ~= "fail" then
        ShowFail(DB.cast.fail[textKey])
    end
end

function UCB:UNIT_SPELLCAST_FAILED(unit)
    OnCastFailure(unit, "failedText")
end

function UCB:UNIT_SPELLCAST_INTERRUPTED(unit)
    OnCastFailure(unit, "interruptedText")
end

function UCB:UNIT_SPELLCAST_SUCCEEDED(unit, spell)
    if unit ~= "player" then return end
    local cb = Bars.cast
    if cb and cb.state == "cast" and cb.spellName == spell then cb.succeeded = true end
    if rangedSpell[spell] then
        local speed = UnitRangedDamage("player")
        StartSwing("ranged", speed)
    end
end

function UCB:UNIT_ATTACK_SPEED(unit)
    if unit ~= "player" then return end
    local mhSpeed, ohSpeed = UnitAttackSpeed("player")
    RescaleSwing("mh", mhSpeed)
    RescaleSwing("oh", ohSpeed)
end

function UCB:UNIT_RANGEDDAMAGE(unit)
    if unit ~= "player" then return end
    RescaleSwing("ranged", (UnitRangedDamage("player")))
end

function UCB:PLAYER_EQUIPMENT_CHANGED(slot)
    for key, s in pairs(SLOT) do
        if s == slot then
            local bar = Bars[key]
            if bar.state == "swing" then HideBar(bar) end
        end
    end
end

-- args (3.3.5): timestamp, subevent, sourceGUID, sourceName, sourceFlags, destGUID, destName, destFlags, ...
function UCB:COMBAT_LOG_EVENT_UNFILTERED(_, sub, srcGUID, _, _, _, _, _, arg9, arg10)
    if srcGUID ~= playerGUID then return end
    if sub == "SWING_DAMAGE" or sub == "SWING_MISSED" then
        OnMeleeSwing(sub == "SWING_DAMAGE" and tonumber(arg9) or nil)
    elseif sub == "SPELL_DAMAGE" or sub == "SPELL_MISSED" then
        if arg10 and nextMelee[arg10] then
            local mhSpeed = UnitAttackSpeed("player")
            StartSwing("mh", mhSpeed)
        end
    end
end

UCB:SetScript("OnEvent", function(self, event, ...)
    local h = self[event]
    if h then h(self, ...) end
end)
UCB:RegisterEvent("ADDON_LOADED")
UCB:RegisterEvent("PLAYER_LOGIN")

---------------------------------------------------------------------------
-- Comandos
---------------------------------------------------------------------------
SLASH_UICASTBAR1 = "/ucb"
SLASH_UICASTBAR2 = "/uicastbar"
SlashCmdList["UICASTBAR"] = function(msg)
    msg = lower(msg or "")
    if msg == "test" then
        ns.SetTest(not UCB.test)
        Print(UCB.test and T("modo de prueba activado") or T("modo de prueba desactivado"))
    elseif msg == "unlock" then
        ns.SetUnlocked(true); Print(T("barras desbloqueadas: arrástralas con el mouse"))
    elseif msg == "lock" then
        ns.SetUnlocked(false); Print(T("barras bloqueadas"))
    elseif msg == "group" then
        DB.groupMove = not DB.groupMove
        if ns.RefreshOptions then ns.RefreshOptions() end
        Print(DB.groupMove and T("mover las 4 barras juntas: ACTIVADO") or T("mover las 4 barras juntas: desactivado"))
    elseif msg == "reset" then
        ns.ResetAll(); Print(T("configuración restablecida"))
    else
        if ns.OpenConfig then ns.OpenConfig() end
    end
end

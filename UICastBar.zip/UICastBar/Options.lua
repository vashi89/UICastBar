--[[ UI Cast Bar - Panel de opciones (3.3.5a) - Autor: vash ]]
local ADDON_NAME, ns = ...
local UCB = ns.UCB
local T = ns.T
local UIFONT = ns.LOCAL_FONT

local floor, max, min, abs = math.floor, math.max, math.min, math.abs
local format, gmatch, match = string.format, string.gmatch, string.match
local pairs, ipairs, type, tonumber, tinsert = pairs, ipairs, type, tonumber, table.insert

local win, scroll
local tabs, tabButtons = {}, {}
local allWidgets = {}
local uid = 0
local picker

local function Name(prefix)
    uid = uid + 1
    return "UICastBar" .. prefix .. uid
end

---------------------------------------------------------------------------
-- Acceso a rutas de la base de datos ("cast.border.size")
---------------------------------------------------------------------------
local function GetPath(path)
    local t = ns.DB
    for k in gmatch(path, "[^%.]+") do
        if type(t) ~= "table" then return nil end
        t = t[k]
    end
    return t
end

local function SetPath(path, value)
    local t = ns.DB
    local parts = {}
    for k in gmatch(path, "[^%.]+") do parts[#parts + 1] = k end
    for i = 1, #parts - 1 do t = t[parts[i]] end
    t[parts[#parts]] = value
end

local function Changed(path)
    local key = match(path, "^[^%.]+")
    if key == "hideBlizzard" then
        ns.ApplyHideBlizzard()
    else
        ns.ApplyKey(key)
    end
end

---------------------------------------------------------------------------
-- Listas fijas para los selectores
---------------------------------------------------------------------------
local LISTS = {
    outline = {
        { value = "NONE", text = "Ninguno" },
        { value = "OUTLINE", text = "Contorno" },
        { value = "THICKOUTLINE", text = "Contorno grueso" },
        { value = "MONOCHROME", text = "Monocromo" },
        { value = "MONOCHROMEOUTLINE", text = "Monocromo + contorno" },
    },
    timeformat = {
        { value = "REMAIN_TOTAL", text = "Restante / total" },
        { value = "ELAPSED_TOTAL", text = "Transcurrido / total" },
        { value = "REMAIN", text = "Solo restante" },
        { value = "ELAPSED", text = "Solo transcurrido" },
        { value = "NONE", text = "Sin tiempo" },
    },
    align = {
        { value = "LEFT", text = "Izquierda" },
        { value = "CENTER", text = "Centro" },
        { value = "RIGHT", text = "Derecha" },
    },
    strata = {
        { value = "BACKGROUND", text = "BACKGROUND" },
        { value = "LOW", text = "LOW" },
        { value = "MEDIUM", text = "MEDIUM" },
        { value = "HIGH", text = "HIGH" },
        { value = "DIALOG", text = "DIALOG" },
    },
    fill = {
        { value = "FILL", text = "Se llena" },
        { value = "DRAIN", text = "Se vacía" },
    },
    side = {
        { value = "LEFT", text = "Izquierda" },
        { value = "RIGHT", text = "Derecha" },
    },
    spark = {
        { value = "Interface\\CastingBar\\UI-CastingBar-Spark", text = "Chispa de casteo" },
        { value = "Interface\\Buttons\\WHITE8x8", text = "Línea cuadrada" },
    },
}

local function MediaList(kind)
    local out = {}
    for _, n in ipairs(ns.ListMedia(kind)) do
        out[#out + 1] = { value = n, text = n }
    end
    return out
end

local function GetList(kind)
    if kind == "statusbar" or kind == "font" or kind == "border" then
        return MediaList(kind)
    end
    return LISTS[kind]
end

---------------------------------------------------------------------------
-- Selector con lista desplazable
---------------------------------------------------------------------------
local ROWS, ROWH = 14, 20

local function RefreshPicker()
    if not picker or not picker:IsShown() then return end
    local items, off = picker.items, picker.offset
    for i = 1, ROWS do
        local row = picker.rows[i]
        local it = items[off + i]
        if it then
            row.value = it.value
            row.text:SetText(T(it.text))
            if picker.kind == "font" then
                local path = ns.Fetch("font", it.value)
                if not row.text:SetFont(path, 12, "") then row.text:SetFont(UIFONT, 12, "") end
            else
                row.text:SetFont(UIFONT, 12, "")
            end
            if picker.kind == "statusbar" then
                row.bar:SetTexture((ns.Fetch("statusbar", it.value)))
                row.bar:SetVertexColor(0.3, 0.55, 1, 0.8)
                row.bar:Show()
            else
                row.bar:Hide()
            end
            if it.value == picker.current then
                row.text:SetTextColor(1, 0.82, 0)
            else
                row.text:SetTextColor(1, 1, 1)
            end
            row:Show()
        else
            row:Hide()
        end
    end
end

local function BuildPicker()
    picker = CreateFrame("Frame", "UICastBarPicker", UIParent)
    picker:SetFrameStrata("TOOLTIP")
    picker:SetWidth(240)
    picker:SetHeight(ROWS * ROWH + 16)
    picker:SetClampedToScreen(true)
    picker:EnableMouse(true)
    picker:EnableMouseWheel(true)
    picker:SetBackdrop({
        bgFile = "Interface\\Buttons\\WHITE8x8",
        edgeFile = "Interface\\Tooltips\\UI-Tooltip-Border",
        edgeSize = 14, insets = { left = 3, right = 3, top = 3, bottom = 3 },
    })
    picker:SetBackdropColor(0.05, 0.05, 0.08, 0.97)
    picker:SetBackdropBorderColor(0.8, 0.8, 0.8, 1)
    picker:Hide()
    picker.rows = {}
    picker.items = {}
    picker.offset = 0

    for i = 1, ROWS do
        local b = CreateFrame("Button", nil, picker)
        b:SetHeight(ROWH)
        b:SetPoint("TOPLEFT", picker, "TOPLEFT", 8, -8 - (i - 1) * ROWH)
        b:SetPoint("TOPRIGHT", picker, "TOPRIGHT", -26, -8 - (i - 1) * ROWH)
        b.bar = b:CreateTexture(nil, "BACKGROUND")
        b.bar:SetAllPoints(b)
        b.bar:Hide()
        b.hl = b:CreateTexture(nil, "HIGHLIGHT")
        b.hl:SetAllPoints(b)
        b.hl:SetTexture(1, 1, 1, 0.25)
        b.text = b:CreateFontString(nil, "OVERLAY")
        b.text:SetFont(UIFONT, 12, "")
        b.text:SetPoint("LEFT", b, "LEFT", 4, 0)
        b.text:SetJustifyH("LEFT")
        b:SetScript("OnClick", function(self)
            local cb, v = picker.onSelect, self.value
            picker:Hide()
            if cb then cb(v) end
        end)
        picker.rows[i] = b
    end

    local sl = CreateFrame("Slider", nil, picker)
    sl:SetOrientation("VERTICAL")
    sl:SetWidth(14)
    sl:SetPoint("TOPRIGHT", picker, "TOPRIGHT", -8, -8)
    sl:SetPoint("BOTTOMRIGHT", picker, "BOTTOMRIGHT", -8, 8)
    sl:SetThumbTexture("Interface\\Buttons\\UI-SliderBar-Button-Vertical")
    local th = sl:GetThumbTexture()
    th:SetWidth(14)
    th:SetHeight(24)
    sl.bg = sl:CreateTexture(nil, "BACKGROUND")
    sl.bg:SetAllPoints(sl)
    sl.bg:SetTexture(1, 1, 1, 0.08)
    sl:SetMinMaxValues(0, 1)
    sl:SetValueStep(1)
    sl:SetValue(0)
    sl:SetScript("OnValueChanged", function(self, v)
        picker.offset = floor(v + 0.5)
        RefreshPicker()
    end)
    picker.slider = sl

    picker:SetScript("OnMouseWheel", function(self, delta)
        local v = sl:GetValue() - delta * 3
        local lo, hi = sl:GetMinMaxValues()
        if v < lo then v = lo elseif v > hi then v = hi end
        sl:SetValue(v)
    end)

    -- capturador para cerrar al hacer click fuera
    local catcher = CreateFrame("Button", nil, UIParent)
    catcher:SetAllPoints(UIParent)
    catcher:SetFrameStrata("FULLSCREEN_DIALOG")
    catcher:Hide()
    catcher:SetScript("OnClick", function() picker:Hide() end)
    picker.catcher = catcher
    picker:SetScript("OnShow", function() catcher:Show() end)
    picker:SetScript("OnHide", function() catcher:Hide() end)
end

local function ShowPicker(anchor, items, current, kind, onSelect)
    if not picker then BuildPicker() end
    picker.items = items
    picker.current = current
    picker.kind = kind
    picker.onSelect = onSelect
    local n = #items
    local maxOff = max(0, n - ROWS)
    local startOff = 0
    for i, it in ipairs(items) do
        if it.value == current then startOff = min(maxOff, max(0, i - floor(ROWS / 2))); break end
    end
    picker:ClearAllPoints()
    picker:SetPoint("TOPLEFT", anchor, "BOTTOMLEFT", 0, -2)
    picker.slider:SetMinMaxValues(0, maxOff)
    picker.slider:SetValue(startOff)
    picker.offset = startOff
    if maxOff == 0 then picker.slider:Hide() else picker.slider:Show() end
    picker:Show()
    RefreshPicker()
end

---------------------------------------------------------------------------
-- Widgets
---------------------------------------------------------------------------
local function NewRow(tab, h)
    h = h or 26
    local row = CreateFrame("Frame", nil, tab)
    row:SetHeight(h)
    row:SetPoint("TOPLEFT", tab, "TOPLEFT", 6, -tab.y)
    row:SetPoint("TOPRIGHT", tab, "TOPRIGHT", -6, -tab.y)
    tab.y = tab.y + h
    return row
end

local function RowLabel(row, text)
    local l = row:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
    l:SetPoint("LEFT", row, "LEFT", 4, 0)
    l:SetWidth(180)
    l:SetJustifyH("LEFT")
    l:SetText(T(text))
    return l
end

local function AddHeader(tab, text)
    tab.y = tab.y + 8
    local row = NewRow(tab, 22)
    local fs = row:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    fs:SetPoint("LEFT", row, "LEFT", 0, 0)
    fs:SetText(T(text))
    local line = row:CreateTexture(nil, "ARTWORK")
    line:SetHeight(1)
    line:SetPoint("BOTTOMLEFT", row, "BOTTOMLEFT", 0, 0)
    line:SetPoint("BOTTOMRIGHT", row, "BOTTOMRIGHT", 0, 0)
    line:SetTexture(1, 0.82, 0, 0.5)
end

local function AddCheck(tab, label, path)
    local row = NewRow(tab, 26)
    local name = Name("Check")
    local cb = CreateFrame("CheckButton", name, row, "InterfaceOptionsCheckButtonTemplate")
    cb:SetPoint("LEFT", row, "LEFT", 0, 0)
    _G[name .. "Text"]:SetText(T(label))
    cb:SetScript("OnClick", function(self)
        SetPath(path, self:GetChecked() and true or false)
        Changed(path)
    end)
    local w = { Refresh = function() cb:SetChecked(GetPath(path) and true or false) end }
    allWidgets[#allWidgets + 1] = w
    w.Refresh()
end

local function AddSlider(tab, label, path, lo, hi, step)
    local row = NewRow(tab, 28)
    RowLabel(row, label)
    local name = Name("Slider")
    local sl = CreateFrame("Slider", name, row, "OptionsSliderTemplate")
    sl:SetPoint("LEFT", row, "LEFT", 190, 0)
    sl:SetWidth(150)
    sl:SetHeight(16)
    sl:SetMinMaxValues(lo, hi)
    sl:SetValueStep(step)
    _G[name .. "Low"]:SetText("")
    _G[name .. "High"]:SetText("")
    _G[name .. "Text"]:SetText("")

    local ename = Name("Edit")
    local eb = CreateFrame("EditBox", ename, row, "InputBoxTemplate")
    eb:SetWidth(54)
    eb:SetHeight(20)
    eb:SetPoint("LEFT", sl, "RIGHT", 14, 0)
    eb:SetAutoFocus(false)
    eb:SetJustifyH("CENTER")
    eb:SetMaxLetters(8)

    local function fmt(v)
        if step >= 1 then return format("%d", v) end
        if step >= 0.1 then return format("%.1f", v) end
        return format("%.2f", v)
    end

    sl:SetScript("OnValueChanged", function(self, v)
        if self.ignore then return end
        v = floor(v / step + 0.5) * step
        v = tonumber(format("%.3f", v))
        eb:SetText(fmt(v))
        if GetPath(path) == v then return end
        SetPath(path, v)
        Changed(path)
    end)
    eb:SetScript("OnEnterPressed", function(self)
        local n = tonumber(self:GetText())
        if n then
            if n < lo then n = lo elseif n > hi then n = hi end
            sl:SetValue(n)
        else
            self:SetText(fmt(GetPath(path) or lo))
        end
        self:ClearFocus()
    end)
    eb:SetScript("OnEscapePressed", function(self)
        self:SetText(fmt(GetPath(path) or lo))
        self:ClearFocus()
    end)

    local w = {
        Refresh = function()
            local v = GetPath(path) or lo
            sl.ignore = true
            sl:SetValue(v)
            sl.ignore = false
            eb:SetText(fmt(v))
        end,
    }
    allWidgets[#allWidgets + 1] = w
    w.Refresh()
end

local function OpenColor(c, hasAlpha, onChange)
    local r, g, b, a = c[1], c[2], c[3], c[4] or 1
    ColorPickerFrame.func = nil
    ColorPickerFrame.opacityFunc = nil
    ColorPickerFrame.cancelFunc = nil
    ColorPickerFrame.hasOpacity = hasAlpha and true or false
    ColorPickerFrame.opacity = 1 - a
    ColorPickerFrame.previousValues = { r, g, b, a }
    ColorPickerFrame:SetColorRGB(r, g, b)
    ColorPickerFrame.func = function()
        local nr, ng, nb = ColorPickerFrame:GetColorRGB()
        c[1], c[2], c[3] = nr, ng, nb
        onChange()
    end
    ColorPickerFrame.opacityFunc = function()
        if hasAlpha then c[4] = 1 - OpacitySliderFrame:GetValue() end
        onChange()
    end
    ColorPickerFrame.cancelFunc = function(prev)
        c[1], c[2], c[3], c[4] = prev[1], prev[2], prev[3], prev[4]
        onChange()
    end
    ColorPickerFrame:Hide()
    ColorPickerFrame:Show()
end

local function AddColor(tab, label, path, hasAlpha)
    local row = NewRow(tab, 26)
    RowLabel(row, label)
    local btn = CreateFrame("Button", nil, row)
    btn:SetWidth(44)
    btn:SetHeight(18)
    btn:SetPoint("LEFT", row, "LEFT", 190, 0)
    local border = btn:CreateTexture(nil, "BACKGROUND")
    border:SetAllPoints(btn)
    border:SetTexture(0.8, 0.8, 0.8, 1)
    local sw = btn:CreateTexture(nil, "ARTWORK")
    sw:SetPoint("TOPLEFT", btn, "TOPLEFT", 1, -1)
    sw:SetPoint("BOTTOMRIGHT", btn, "BOTTOMRIGHT", -1, 1)
    local hl = btn:CreateTexture(nil, "HIGHLIGHT")
    hl:SetAllPoints(btn)
    hl:SetTexture(1, 1, 1, 0.25)
    local function paint()
        local c = GetPath(path)
        if c then sw:SetTexture(c[1], c[2], c[3], 1) end
    end
    btn:SetScript("OnClick", function()
        local c = GetPath(path)
        if not c then return end
        OpenColor(c, hasAlpha, function() paint(); Changed(path) end)
    end)
    local w = { Refresh = paint }
    allWidgets[#allWidgets + 1] = w
    paint()
end

local function AddPick(tab, label, path, kind)
    local row = NewRow(tab, 28)
    RowLabel(row, label)
    local btn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    btn:SetWidth(200)
    btn:SetHeight(22)
    btn:SetPoint("LEFT", row, "LEFT", 190, 0)
    local function refresh()
        local cur = GetPath(path)
        local shown = tostring(cur)
        local list = LISTS[kind]
        if list then
            for _, it in ipairs(list) do
                if it.value == cur then shown = it.text; break end
            end
        end
        btn:SetText(T(shown))
    end
    btn:SetScript("OnClick", function(self)
        ShowPicker(self, GetList(kind), GetPath(path), kind, function(v)
            SetPath(path, v)
            refresh()
            Changed(path)
        end)
    end)
    local w = { Refresh = refresh }
    allWidgets[#allWidgets + 1] = w
    refresh()
end

local function AddEdit(tab, label, path)
    local row = NewRow(tab, 28)
    RowLabel(row, label)
    local eb = CreateFrame("EditBox", Name("Edit"), row, "InputBoxTemplate")
    eb:SetWidth(190)
    eb:SetHeight(20)
    eb:SetPoint("LEFT", row, "LEFT", 196, 0)
    eb:SetAutoFocus(false)
    eb:SetMaxLetters(40)
    eb:SetScript("OnEnterPressed", function(self)
        SetPath(path, self:GetText())
        Changed(path)
        self:ClearFocus()
    end)
    eb:SetScript("OnEscapePressed", function(self)
        self:SetText(GetPath(path) or "")
        self:ClearFocus()
    end)
    local w = { Refresh = function() eb:SetText(GetPath(path) or "") end }
    allWidgets[#allWidgets + 1] = w
    w.Refresh()
end

local function AddButton(tab, label, onClick, width)
    local row = NewRow(tab, 30)
    local btn = CreateFrame("Button", nil, row, "UIPanelButtonTemplate")
    btn:SetWidth(width or 220)
    btn:SetHeight(24)
    btn:SetPoint("LEFT", row, "LEFT", 4, 0)
    btn:SetText(T(label))
    btn:SetScript("OnClick", onClick)
    return btn
end

local function AddNote(tab, text)
    local row = NewRow(tab, 40)
    local fs = row:CreateFontString(nil, "OVERLAY", "GameFontHighlightSmall")
    fs:SetPoint("TOPLEFT", row, "TOPLEFT", 4, -2)
    fs:SetPoint("TOPRIGHT", row, "TOPRIGHT", -4, -2)
    fs:SetJustifyH("LEFT")
    fs:SetText(T(text))
end

---------------------------------------------------------------------------
-- Especificaciones de cada pestaña
---------------------------------------------------------------------------
local function TextSpec(s, prefix, title, withEnable)
    s[#s + 1] = { "header", title }
    if withEnable then s[#s + 1] = { "check", "Mostrar", prefix .. ".enabled" } end
    s[#s + 1] = { "pick", "Fuente", prefix .. ".font", "font" }
    s[#s + 1] = { "slider", "Tamaño", prefix .. ".size", 6, 40, 1 }
    s[#s + 1] = { "pick", "Contorno", prefix .. ".outline", "outline" }
    s[#s + 1] = { "color", "Color", prefix .. ".color", true }
    s[#s + 1] = { "pick", "Alineación", prefix .. ".align", "align" }
    s[#s + 1] = { "slider", "Desplazamiento X", prefix .. ".x", -200, 200, 1 }
    s[#s + 1] = { "slider", "Desplazamiento Y", prefix .. ".y", -50, 50, 1 }
    s[#s + 1] = { "check", "Sombra", prefix .. ".shadow" }
end

local function BorderSpec(s, prefix, title)
    s[#s + 1] = { "header", title }
    s[#s + 1] = { "check", "Mostrar borde", prefix .. ".enabled" }
    s[#s + 1] = { "pick", "Estilo", prefix .. ".style", "border" }
    s[#s + 1] = { "slider", "Grosor", prefix .. ".size", 1, 32, 1 }
    s[#s + 1] = { "slider", "Separación", prefix .. ".offset", -10, 20, 1 }
    s[#s + 1] = { "color", "Color", prefix .. ".color", true }
end

local function BarSpecs(k, isCast)
    local s = {}
    s[#s + 1] = { "header", "Posición y tamaño" }
    s[#s + 1] = { "check", "Barra activada", k .. ".enabled" }
    s[#s + 1] = { "slider", "Ancho", k .. ".width", 20, 800, 1 }
    s[#s + 1] = { "slider", "Alto", k .. ".height", 4, 100, 1 }
    s[#s + 1] = { "slider", "Escala", k .. ".scale", 0.3, 3, 0.01 }
    s[#s + 1] = { "slider", "Posición X", k .. ".x", -1400, 1400, 0.5 }
    s[#s + 1] = { "slider", "Posición Y", k .. ".y", -900, 900, 0.5 }
    s[#s + 1] = { "slider", "Transparencia", k .. ".alpha", 0, 1, 0.05 }
    s[#s + 1] = { "pick", "Capa (strata)", k .. ".strata", "strata" }

    s[#s + 1] = { "header", "Apariencia" }
    s[#s + 1] = { "pick", "Textura", k .. ".texture", "statusbar" }
    s[#s + 1] = { "color", "Color de la barra", k .. ".color", true }
    s[#s + 1] = { "color", "Color de fondo", k .. ".bgColor", true }
    s[#s + 1] = { "pick", isCast and "Relleno al castear" or "Relleno", k .. ".fill", "fill" }
    if isCast then
        s[#s + 1] = { "pick", "Relleno al canalizar", k .. ".channelFill", "fill" }
    end

    s[#s + 1] = { "header", "Chispa (spark)" }
    s[#s + 1] = { "check", "Mostrar chispa", k .. ".spark.enabled" }
    s[#s + 1] = { "pick", "Textura de chispa", k .. ".spark.texture", "spark" }
    s[#s + 1] = { "color", "Color", k .. ".spark.color", true }
    s[#s + 1] = { "slider", "Ancho", k .. ".spark.width", 1, 80, 1 }
    s[#s + 1] = { "slider", "Alto", k .. ".spark.height", 2, 120, 1 }
    if not isCast then
        s[#s + 1] = { "check", "Ocultar chispa si la barra está vacía/llena", k .. ".spark.hideWhenEmpty" }
    end

    BorderSpec(s, k .. ".border", "Borde de la barra")

    if isCast then
        TextSpec(s, k .. ".nameText", "Texto: nombre del hechizo", true)
    end
    TextSpec(s, k .. ".timeText", "Texto: tiempo", true)
    s[#s + 1] = { "pick", "Formato del tiempo", k .. ".timeFormat", "timeformat" }

    if isCast then
        s[#s + 1] = { "header", "Icono del hechizo" }
        s[#s + 1] = { "check", "Mostrar icono", k .. ".icon.enabled" }
        s[#s + 1] = { "slider", "Tamaño", k .. ".icon.size", 8, 120, 1 }
        s[#s + 1] = { "slider", "Posición X (respecto a la barra)", k .. ".icon.x", -400, 400, 0.5 }
        s[#s + 1] = { "slider", "Posición Y (respecto a la barra)", k .. ".icon.y", -200, 200, 0.5 }
        s[#s + 1] = { "check", "Recortar bordes del icono", k .. ".icon.zoom" }
        s[#s + 1] = { "check", "Efecto zoom del icono al empezar a castear", k .. ".icon.pop.enabled" }
        s[#s + 1] = { "slider", "Zoom máximo del icono", k .. ".icon.pop.scale", 1.05, 3, 0.05 }
        s[#s + 1] = { "slider", "Duración del zoom (seg)", k .. ".icon.pop.duration", 0.1, 1, 0.05 }
        BorderSpec(s, k .. ".icon.border", "Borde del icono")

        s[#s + 1] = { "header", "Fallo del casteo (fondo rojo)" }
        s[#s + 1] = { "check", "Mostrar barra roja completa al fallar", k .. ".fail.enabled" }
        s[#s + 1] = { "color", "Color del fallo", k .. ".fail.color", true }
        s[#s + 1] = { "slider", "Duración (segundos)", k .. ".fail.duration", 0.2, 4, 0.1 }
        s[#s + 1] = { "edit", "Texto al fallar", k .. ".fail.failedText" }
        s[#s + 1] = { "edit", "Texto al ser interrumpido", k .. ".fail.interruptedText" }
        s[#s + 1] = { "edit", "Texto al cancelar tú el casteo", k .. ".fail.cancelText" }
        s[#s + 1] = { "check", "Mostrar también si falla sin estar casteando", k .. ".fail.showWithoutCast" }

        s[#s + 1] = { "header", "Latencia" }
        s[#s + 1] = { "check", "Mostrar latencia en la barra", k .. ".latency.enabled" }
        s[#s + 1] = { "color", "Color de latencia", k .. ".latency.color", true }

        s[#s + 1] = { "header", "Color al terminar el casteo" }
        s[#s + 1] = { "check", "Cambiar color al final", k .. ".endColor.enabled" }
        s[#s + 1] = { "slider", "Segundos restantes", k .. ".endColor.threshold", 0.02, 1, 0.01 }
        s[#s + 1] = { "color", "Color final", k .. ".endColor.color", true }
    else
        s[#s + 1] = { "header", "Icono del arma" }
        s[#s + 1] = { "check", "Mostrar icono", k .. ".icon.enabled" }
        s[#s + 1] = { "pick", "Lado del icono", k .. ".icon.side", "side" }
    end
    return s
end

local function BuildSpecs(tab, specs)
    for _, sp in ipairs(specs) do
        local t = sp[1]
        if t == "header" then AddHeader(tab, sp[2])
        elseif t == "check" then AddCheck(tab, sp[2], sp[3])
        elseif t == "slider" then AddSlider(tab, sp[2], sp[3], sp[4], sp[5], sp[6])
        elseif t == "color" then AddColor(tab, sp[2], sp[3], sp[4])
        elseif t == "pick" then AddPick(tab, sp[2], sp[3], sp[4])
        elseif t == "edit" then AddEdit(tab, sp[2], sp[3])
        end
    end
end

---------------------------------------------------------------------------
-- Ventana
---------------------------------------------------------------------------
local function SelectTab(i)
    for idx, t in ipairs(tabs) do
        if idx == i then
            if not t.built then
                t.build(t)
                t:SetHeight(t.y + 20)
                t.built = true
            end
            t:Show()
            scroll:SetScrollChild(t)
            scroll:SetVerticalScroll(0)
            tabButtons[idx]:Disable()
        else
            t:Hide()
            tabButtons[idx]:Enable()
        end
    end
    win.current = i
end

local function AddTab(title, buildFunc)
    local i = #tabs + 1
    local t = CreateFrame("Frame", nil, win)
    t:SetWidth(470)
    t:SetHeight(100)
    t.y = 4
    t.build = buildFunc
    t:Hide()
    tabs[i] = t

    local b = CreateFrame("Button", Name("Tab"), win, "UIPanelButtonTemplate")
    b:SetWidth(128)
    b:SetHeight(26)
    b:SetPoint("TOPLEFT", win, "TOPLEFT", 14, -44 - (i - 1) * 30)
    b:SetText(T(title))
    b:SetScript("OnClick", function() SelectTab(i) end)
    tabButtons[i] = b
end

local function BuildGeneral(tab)
    AddHeader(tab, "General")
    AddCheck(tab, "Ocultar la barra de casteo original de Blizzard", "hideBlizzard")
    AddNote(tab, "Si lo desactivas, la barra original vuelve a usarse; para restaurarla por completo usa /reload.")
    AddButton(tab, "Desbloquear / bloquear barras (mover con el mouse)", function()
        ns.SetUnlocked(not UCB.unlocked)
    end, 330)
    AddCheck(tab, "Mover las 4 barras juntas al arrastrar", "groupMove")
    AddButton(tab, "Probar (animación de casteo, fallo y swing)", function()
        ns.SetTest(not UCB.test)
    end, 330)
    AddButton(tab, "Restablecer TODO a los valores originales", function()
        StaticPopup_Show("UICASTBAR_RESET")
    end, 330)
    AddHeader(tab, "Barras activas")
    AddCheck(tab, "Barra de casteo", "cast.enabled")
    AddCheck(tab, "Swing mano principal", "mh.enabled")
    AddCheck(tab, "Swing mano izquierda", "oh.enabled")
    AddCheck(tab, "Swing a distancia", "ranged.enabled")
    AddHeader(tab, "Comandos")
    AddNote(tab, "/ucb  abre este panel\n/ucb unlock | lock  mueve las barras con el mouse\n/ucb group  mueve las 4 barras juntas (on/off)\n/ucb test  animación de prueba\n/ucb reset  restablece todo")
end

local function BuildWindow()
    StaticPopupDialogs["UICASTBAR_RESET"] = {
        text = T("Restablecer toda la configuración de UI Cast Bar?"),
        button1 = YES, button2 = NO,
        OnAccept = function() ns.ResetAll() end,
        timeout = 0, whileDead = 1, hideOnEscape = 1,
    }

    win = CreateFrame("Frame", "UICastBarConfig", UIParent)
    win:SetWidth(660)
    win:SetHeight(560)
    win:SetPoint("CENTER", UIParent, "CENTER", 0, 20)
    win:SetFrameStrata("DIALOG")
    win:SetMovable(true)
    win:SetClampedToScreen(true)
    win:EnableMouse(true)
    win:RegisterForDrag("LeftButton")
    win:SetScript("OnDragStart", function(self) self:StartMoving() end)
    win:SetScript("OnDragStop", function(self) self:StopMovingOrSizing() end)
    win:SetBackdrop({
        bgFile = "Interface\\DialogFrame\\UI-DialogBox-Background",
        edgeFile = "Interface\\DialogFrame\\UI-DialogBox-Border",
        tile = true, tileSize = 32, edgeSize = 32,
        insets = { left = 11, right = 12, top = 12, bottom = 11 },
    })
    win:Hide()
    tinsert(UISpecialFrames, "UICastBarConfig")

    local title = win:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
    title:SetPoint("TOP", win, "TOP", 0, -16)
    title:SetText("UI Cast Bar")

    local close = CreateFrame("Button", nil, win, "UIPanelCloseButton")
    close:SetPoint("TOPRIGHT", win, "TOPRIGHT", -6, -6)

    scroll = CreateFrame("ScrollFrame", "UICastBarConfigScroll", win, "UIPanelScrollFrameTemplate")
    scroll:SetPoint("TOPLEFT", win, "TOPLEFT", 156, -44)
    scroll:SetPoint("BOTTOMRIGHT", win, "BOTTOMRIGHT", -34, 16)

    AddTab("General", BuildGeneral)
    AddTab("Barra de casteo", function(t) BuildSpecs(t, BarSpecs("cast", true)) end)
    AddTab("Swing: mano principal", function(t) BuildSpecs(t, BarSpecs("mh", false)) end)
    AddTab("Swing: mano izq.", function(t) BuildSpecs(t, BarSpecs("oh", false)) end)
    AddTab("Swing: a distancia", function(t) BuildSpecs(t, BarSpecs("ranged", false)) end)

    win:SetScript("OnShow", function()
        if GameMenuFrame and GameMenuFrame:IsShown() then HideUIPanel(GameMenuFrame) end
    end)
    win:SetScript("OnHide", function()
        if picker then picker:Hide() end
    end)
    SelectTab(1)
end

function ns.RefreshOptions()
    for _, w in ipairs(allWidgets) do w.Refresh() end
end

function ns.OpenConfig()
    if not ns.DB then return end
    if not win then BuildWindow() end
    if win:IsShown() then win:Hide() else win:Show(); ns.RefreshOptions() end
end

---------------------------------------------------------------------------
-- Entrada en Interface Options
---------------------------------------------------------------------------
local panel = CreateFrame("Frame", "UICastBarInterfacePanel", UIParent)
panel.name = "UI Cast Bar"
local ptitle = panel:CreateFontString(nil, "OVERLAY", "GameFontNormalLarge")
ptitle:SetPoint("TOPLEFT", 16, -16)
ptitle:SetText("UI Cast Bar")
local pdesc = panel:CreateFontString(nil, "OVERLAY", "GameFontHighlight")
pdesc:SetPoint("TOPLEFT", ptitle, "BOTTOMLEFT", 0, -8)
pdesc:SetText(T("Barra de casteo y temporizadores de swing. Autor: vash. Comando: /ucb"))
local pbtn = CreateFrame("Button", nil, panel, "UIPanelButtonTemplate")
pbtn:SetWidth(220)
pbtn:SetHeight(24)
pbtn:SetPoint("TOPLEFT", pdesc, "BOTTOMLEFT", 0, -16)
pbtn:SetText(T("Abrir configuración"))
pbtn:SetScript("OnClick", function()
    if InterfaceOptionsFrame then InterfaceOptionsFrame:Hide() end
    if not (win and win:IsShown()) then ns.OpenConfig() end
end)
InterfaceOptions_AddCategory(panel)
